# Gloria Eterna — prototipo

Estrategia por turnos en hexágonos, estilo Civ, donde **las unidades crecen sin límite**:
ganan XP, suben de nivel y cada nivel da 1 punto de promoción (ataque, defensa, vida,
regeneración, sed de sangre, zancada, puntería, aura de mando, doble golpe…).

## Cómo jugar
1. Instala [Node.js](https://nodejs.org) (versión 18 o superior). No hay que instalar nada más.
2. En esta carpeta: `node server.js`  (o `npm start`)
3. Abre `http://localhost:3000`. La consola muestra también la dirección de red local.
4. Tus amigos abren esa dirección (misma wifi), ponen su nombre y se unen.
   El primero en entrar es el anfitrión: pulsa **Empezar partida**. Puedes añadir **bots** para probar solo.

### Jugar por internet
- Lo más fácil: un túnel, p. ej. `cloudflared tunnel --url http://localhost:3000` (o ngrok / playit.gg).
  Compartes la URL que te da.
- Alternativa: VPN tipo Tailscale/ZeroTier, o subir la carpeta a un hosting con Node (Render, Railway…).

### Jugar desde el teléfono
La interfaz se adapta a móviles: el panel pasa a una hoja inferior (arrástrala/tócala para plegarla), un dedo mueve el mapa,
dos dedos hacen zoom y un toque selecciona, mueve o ataca. El botón 📜 muestra el registro.
**Ojo:** el servidor (`node server.js`) tiene que correr en un ordenador o en un hosting; los teléfonos solo abren la dirección.

## Reglas
- Turnos **simultáneos**: todos mueven a la vez; el turno pasa cuando todos pulsan «Terminar turno».
- Hay niebla de guerra. Gana quien deje al resto sin ciudades ni colonos.
- Ciudades: producen unidades (se repite hasta que cambies). La población crece cada 5 turnos.
  Un colono cuesta 1 de población y funda ciudades a ≥3 casillas de otra.
- XP: combatir, matar, conquistar y sobrevivir cada turno. Descansar cura; las ciudades curan más.
- Terreno: bosque +20% defensa, colinas +40%; montañas y agua son impasables.

## Controles
Clic: seleccionar / mover / atacar (rojo) · Arrastrar: mover mapa · Rueda: zoom ·
`Espacio` siguiente unidad · `Enter` terminar turno · `F` fundar ciudad · `H` ir a tu capital · `Esc` deseleccionar.

## Archivos
- `game.js`: reglas (mapa, combate, XP/promociones, bots). `server.js`: servidor. `index.html`: cliente (todo está en la raíz, sin carpetas).
- `test.js` y `e2e.js`: pruebas (`npm test`).

## Ideas para seguir
Más unidades y edificios, árboles tecnológicos, recursos, promociones por rama, unidades navales,
guardado de partida, equipos/alianzas, más tipos de victoria.
